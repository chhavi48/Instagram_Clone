// import { Avatar } from '@mui/material'
import React from 'react'
//  import { Avatar } from '@chakra-ui/react'
// import "./Story.css"
const Story = () => {
  return (
   
   <div></div>

  )
}

export default Story